package databaseW12SH2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Q2 {
	public static void main(String[] args) throws Exception {
		String url = "jdbc:mysql://localhost:3306/e";
		String uName = "root";
		String pass = "toor";

		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection(url, uName, pass);
		Statement st = con.createStatement();
		st = con.createStatement();
		String query = "Insert Into employees values (001,'Vaibhav', 'Mehandiratta', 10000, 50, 'vab@gmail.com', 'Yamunanagar')";
		st.executeUpdate(query);
		query = "Insert Into employees values (002,'Manpreet', 'Kohli', 20000, 30, 'mk@gmail.com', 'Chandigarh')";
		st.executeUpdate(query);
		query = "Insert Into employees values (003,'Sawan', 'Gaba', 50000, 20, 'sg@gmail.com','Ambala')";
		st.executeUpdate(query);
		query = "Insert Into employees values (004,'Garvit', 'Kumar', 60000, 10, 'gk@gmail.com', 'Chandigarh')";
		st.executeUpdate(query);
		query = "Insert Into employees values (005,'Jaspreet', 'Singh', 90000, 50, 'js@gmail.com', 'Mumbai')";
		st.executeUpdate(query);
		query = "Insert Into employees values (006,'Nipun', 'Kataria', 70000, 10, 'nk@gmail.com','Delhi')";
		st.executeUpdate(query);
		query = "Insert Into employees values (007,'Anshul', 'Sharma', 20000, 20, 'as@gmail.com','Pune')";
		st.executeUpdate(query);
		query = "Insert Into employees values (008,'Sparsh', 'Goel', 40000, 50, 'sg@gmail.com', 'Delhi')";
		st.executeUpdate(query);
		query = "Insert Into employees values (009,'Harshit', 'Garg', 75000, 10, 'hg@gmail.com','Mumbai')";
		st.executeUpdate(query);
		query = "Insert Into employees values (010,'Piyush', 'Malhotra', 10000, 50, 'pm@gmail.com','Yamunanagar')";
		st.executeUpdate(query);

		st.close();
		con.close();
	}
}
