package HBase;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.util.Bytes;

public class Create_cmd {
	
	
	public static void main(String[] args) throws IOException
	{
		
		Configuration config = HBaseConfiguration.create();
		HBaseAdmin admin = new HBaseAdmin(config);
		HTableDescriptor des= new HTableDescriptor(Bytes.toBytes("Std_Table"));
		HColumnDescriptor hcd = new HColumnDescriptor(Bytes.toBytes("Std_Courses"));
		HColumnDescriptor hc1 = new HColumnDescriptor(Bytes.toBytes("Std_Data"));
		

		HTableDescriptor des2= new HTableDescriptor(Bytes.toBytes("demoTable1"));
		HTableDescriptor des1= new HTableDescriptor(Bytes.toBytes("demoTable2"));
		
		des.addFamily(hcd);
		des.addFamily(hc1);
		admin.createTable(des);
		admin.createTable(des1);
		admin.createTable(des2);
	}

}
