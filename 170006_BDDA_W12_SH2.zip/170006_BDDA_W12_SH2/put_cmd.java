package HBase;


import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.util.Bytes;

public class put_cmd {
	
	public static void main(String[] args) throws IOException
	{
		Configuration config = HBaseConfiguration.create();
		HTable ht = new HTable(config, "Std_Table");
		Put put1 = new Put(Bytes.toBytes("1"));
		put1.add(Bytes.toBytes("Std_Courses"), Bytes.toBytes("Course_Name"), Bytes.toBytes("DBCS"));
		put1.add(Bytes.toBytes("Std_Courses"), Bytes.toBytes("Course_ID"), Bytes.toBytes("1"));
		put1.add(Bytes.toBytes("Std_Courses"), Bytes.toBytes("Enrolled_Students"), Bytes.toBytes("60"));
		
		put1.add(Bytes.toBytes("Std_Data"), Bytes.toBytes("first_Name"), Bytes.toBytes("Vaibhav"));
		put1.add(Bytes.toBytes("Std_Data"), Bytes.toBytes("last_Name"), Bytes.toBytes("Mehandiratta"));
		put1.add(Bytes.toBytes("Std_Data"), Bytes.toBytes("city"), Bytes.toBytes("Yamunanagar"));
		

		Put put2 = new Put(Bytes.toBytes("2"));
		put2.add(Bytes.toBytes("Std_Courses"), Bytes.toBytes("Course_Name"), Bytes.toBytes("NetworkSecurity"));
		put2.add(Bytes.toBytes("Std_Courses"), Bytes.toBytes("Course_ID"), Bytes.toBytes("2"));
		put2.add(Bytes.toBytes("Std_Courses"), Bytes.toBytes("Enrolled_Students"), Bytes.toBytes("60"));
		
		put2.add(Bytes.toBytes("Std_Data"), Bytes.toBytes("first_Name"), Bytes.toBytes("Manpreet"));
		put2.add(Bytes.toBytes("Std_Data"), Bytes.toBytes("last_Name"), Bytes.toBytes("Kohli"));
		put2.add(Bytes.toBytes("Std_Data"), Bytes.toBytes("city"), Bytes.toBytes("Yamunanagar"));
		
		
		Put put3 = new Put(Bytes.toBytes("3"));
		put3.add(Bytes.toBytes("Std_Courses"), Bytes.toBytes("Course_Name"), Bytes.toBytes("BigData"));
		put3.add(Bytes.toBytes("Std_Courses"), Bytes.toBytes("Course_ID"), Bytes.toBytes("3"));
		put3.add(Bytes.toBytes("Std_Courses"), Bytes.toBytes("Enrolled_Students"), Bytes.toBytes("60"));
		
		put3.add(Bytes.toBytes("Std_Data"), Bytes.toBytes("first_Name"), Bytes.toBytes("Garvit"));
		put3.add(Bytes.toBytes("Std_Data"), Bytes.toBytes("last_Name"), Bytes.toBytes("Kumar"));
		put3.add(Bytes.toBytes("Std_Data"), Bytes.toBytes("city"), Bytes.toBytes("Yamunanagar"));
		
		
		Put put4 = new Put(Bytes.toBytes("4"));
		put4.add(Bytes.toBytes("Std_Courses"), Bytes.toBytes("Course_Name"), Bytes.toBytes("MobileApps"));
		put4.add(Bytes.toBytes("Std_Courses"), Bytes.toBytes("Course_ID"), Bytes.toBytes("4"));
		put4.add(Bytes.toBytes("Std_Courses"), Bytes.toBytes("Enrolled_Students"), Bytes.toBytes("15"));
		
		put4.add(Bytes.toBytes("Std_Data"), Bytes.toBytes("first_Name"), Bytes.toBytes("Nipun"));
		put4.add(Bytes.toBytes("Std_Data"), Bytes.toBytes("last_Name"), Bytes.toBytes("Kataria"));
		put4.add(Bytes.toBytes("Std_Data"), Bytes.toBytes("city"), Bytes.toBytes("Jagadhri"));
		
		
		Put put5 = new Put(Bytes.toBytes("5"));
		put5.add(Bytes.toBytes("Std_Courses"), Bytes.toBytes("Course_Name"), Bytes.toBytes("Statistics"));
		put5.add(Bytes.toBytes("Std_Courses"), Bytes.toBytes("Course_ID"), Bytes.toBytes("5"));
		put5.add(Bytes.toBytes("Std_Courses"), Bytes.toBytes("Enrolled_Students"), Bytes.toBytes("60"));
		
		put5.add(Bytes.toBytes("Std_Data"), Bytes.toBytes("first_Name"), Bytes.toBytes("Harshit"));
		put5.add(Bytes.toBytes("Std_Data"), Bytes.toBytes("last_Name"), Bytes.toBytes("Garg"));
		put5.add(Bytes.toBytes("Std_Data"), Bytes.toBytes("city"), Bytes.toBytes("Yamunanagar"));
		
		ht.put(put1);
		ht.put(put2);
		ht.put(put3);
		ht.put(put4);
		ht.put(put5);
						
	}

}


